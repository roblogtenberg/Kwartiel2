package configuration;

public class Config {
	public final static int AANTAL_KLANTEN = 222;
	public final static int AANTAL_DISTRIBUTEURS = 10;
	public final static int AANTAL_RIJEN_PER_VAK = 5;
	public final static int AANTAL_STOELEN_PER_RIJ = 4;
	public final static int PERCENTAGE_KANS_OP_ANNULEREN = 50;
	// public final static int AANTAL_KLANTEN = 5;
	// public final static int AANTAL_DISTRIBUTEURS = 10;
	// public final static int AANTAL_RIJEN_PER_VAK = 4;
	// public final static int AANTAL_STOELEN_PER_RIJ = 15;
	// public final static int PERCENTAGE_KANS_OP_ANNULEREN = 50;

}
